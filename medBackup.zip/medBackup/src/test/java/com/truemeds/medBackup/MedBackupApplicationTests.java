package com.truemeds.medBackup;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedBackupApplicationTests {

	@Test
	void contextLoads() {
	}

}
